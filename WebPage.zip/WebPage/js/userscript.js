var urlBase = 'ameade.us/API';
var extension = "php";
var x;
var y;

function loadUserDetails(){
	x = JSON.parse(getCookie("userData"));
	console.log(x);
	document.getElementById("displayName").innerHTML = x.displayName;
  userScore();
  winBoard();
  if(y != 0){
    listContacts();
  }
}

function userScore() 
{
  document.getElementById("Wins").innerHTML = x.gamesWon;
  document.getElementById("Losses").innerHTML = x.gamesLost;
  document.getElementById("Tied").innerHTML = x.gamesTied;
  document.getElementById("gamePlayed").innerHTML = x.gamesPlayed;
}

function listContacts()
{
    var data = y.split(",");
    var ul = document.getElementById("score");
    for( var i = 0; i < data.length; i++ )
    {
      var li = document.createElement("li");
      var data2 = data[i].split(":");
      console.log(data2[0] + "\t\t" + data2[1]);
      var t = document.createTextNode(data2[0] + "\t\t" + data2[1]);
      li.appendChild(t);
      ul.appendChild(li);
  }
}

function winBoard()
{
    var url = /*urlBase +*/ 'API/getWinBoardrpsx.' + extension;
    var xhr = new XMLHttpRequest();
    xhr.open("POST", url, false);
    xhr.setRequestHeader("Content-type", "application/json; charset=UTF-8");
    try
    {
        xhr.send();
        y = xhr.responseText;
        y = y.replace("{","").replace("}","").replace(/"/g, "").replace(/\s/g, "").trim();
        console.log(y);
    }
    catch(err)
    {
        document.getElementById("displayName").innerHTML = err.message;
    }
}

function logout(){
	location.href = "../";
}

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}