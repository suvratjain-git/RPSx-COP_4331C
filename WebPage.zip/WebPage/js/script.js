var urlBase = 'ameade.us/API';
var extension = "php";

var data = "";


// leaderboards - getWinBoard getLossBoard sends it already in order

// Needs : Username, Password, firstName, lastName, displayName, email. on failure sends a 0 on true
// sends a 1 

//Displays 2 if displayName used
//Displays 3 if email used
function createUser()
{
    var newUser = document.getElementById("newUser").value; //taking up the user new name. it should check if the name is not taken yet
    var newPassword = document.getElementById("newPassword").value; //this is a varible to take the password to up. Next step is to make sure the password meet critera (at least 8 character, upper, lower, number and symbol,
    newPassword = sha1(newPassword);

    var firstName = document.getElementById("firstName").value;
    var lastName = document.getElementById("lastName").value;
    var displayName = document.getElementById("displayName").value;
	var email = document.getElementById("email").value;

    var jsonPayload = '{"Username" : "' + newUser + '", "Password" : "' + newPassword + 
    '", "firstName" : "' + firstName + '", "lastName" : "' + lastName + '", "displayName" : "' +
    displayName + '", "email" : "' + email + '"}';
    var url = 'API/addUserWebsiterpsx.' + extension;

    var xhr = new XMLHttpRequest();
    xhr.open("POST", url, false);
    xhr.setRequestHeader("Content-type", "application/json; charset=UTF-8");
    try
    {
        console.log(jsonPayload);
        xhr.send(jsonPayload);
        console.log("sent correctly.");
        var jsonObject = JSON.parse(xhr.responseText);
        console.log(jsonObject);
        
        if(jsonObject != 0) {
            jsonObject = JSON.stringify(jsonObject);
            console.log(jsonObject);
            setCookie("userData", jsonObject, 2);
            location.href = "/userPage.html";
        } else {
            document.getElementById("loginResult").innerHTML = "User/Password combination is incorrect";
        }
    }
    catch(err)
    {
        document.getElementById("addResult").innerHTML = err.message;
    }
}

/// Verify the account: Username, displayName, email, sends back 1 if account is verified, 0 if account does 
/// not exist
function verifyAccount()
{
	var Username = document.getElementById("loginName").value; //taking up the user new name. it should check if the name is not taken yet
    var Password = document.getElementById("loginPassword").value; //this is a varible to take the password to up. Next step is to make sure the password meet critera (at least 8 character, upper, lower, number and symbol,
    Password = sha1(newPassword);

    var displayName = document.getElementById("displayName").value;
	var email = document.getElementById("email").value;

    var jsonPayload = '{"Username" : "' + Username + '", "Password" : "' + Password + 
	'"displayName" : "' + displayName + '"email" : "' + email + '"}';
    
	//Change to verify account .php when Tyler pushes to repo
    var url = '/addUserrpsx.' + extension;

    var xhr = new XMLHttpRequest();
    xhr.open("POST", url, false);
    xhr.setRequestHeader("Content-type", "application/json; charset=UTF-8");
    try
    {
        xhr.onreadystatechange = function()
        {
            if (this.readyState == 4 && this.status == 200)
            {
                //Change id to w/e we end up making the div for placing the confirmation
                document.getElementById("loginResult").innerHTML = "User has been added";
            }
        };
        xhr.send(jsonPayload);
    }
    catch(err)
    {
    	//Change to w/e div id is on that page, verifying account will be the last thing u do
        document.getElementById("addResult").innerHTML = err.message;
    }
}

/// Change password : Username, newPassword, displayName
///
function changePassword()
{
	var Username = document.getElementById("loginName").value; //taking up the user new name. it should check if the name is not taken yet
    var newPassword = document.getElementById("newPassword").value; //this is a varible to take the password to up. Next step is to make sure the password meet critera (at least 8 character, upper, lower, number and symbol,
    newPassword = sha1(newPassword);

    var displayName = document.getElementById("displayName").value;

    var jsonPayload = '{"Username" : "' + Username + '", "Password" : "' + newPassword + 
	'"displayName" : "' + displayName + '"}';
    
	//Change to verify account .php when Tyler pushes to repo
    var url = '/addUserrpsx.' + extension;

    var xhr = new XMLHttpRequest();
    xhr.open("POST", url, false);
    xhr.setRequestHeader("Content-type", "application/json; charset=UTF-8");
    try
    {
        xhr.onreadystatechange = function()
        {
            if (this.readyState == 4 && this.status == 200)
            {
                //Change id to w/e we end up making the div for placing the confirmation
                document.getElementById("loginResult").innerHTML = "User has been added";
            }
        };
        xhr.send(jsonPayload);
    }
    catch(err)
    {
    	//Change to w/e div id is on that page, verifying account will be the last thing u do
        document.getElementById("addResult").innerHTML = err.message;
    }
}

// Send: Username, password Receives: displayName, gamesWon, gamesLost, gamesTied, gamesPlayed.
// on failure sends back a 0
function doLogin()
{

	var login = document.getElementById("loginName").value;
	var password = document.getElementById("loginPassword").value;

    //add the sha1 to take the password and send it off to the server
    password = sha1(password);

	document.getElementById("loginResult").innerHTML = "";

	var jsonPayload = '{"Username" : "' + login + '", "Password" : "' + password + '"}';
	var url = /*urlBase +*/ 'API/Loginrpsx.' + extension;

    console.log(jsonPayload);
	var xhr = new XMLHttpRequest();
	xhr.open("POST", url, false);
	xhr.setRequestHeader("Content-type", "application/json; charset=UTF-8");
	try
	{
		xhr.send(jsonPayload);
		console.log("sent correctly.");
		var jsonObject = JSON.parse(xhr.responseText);
        console.log(jsonObject);
		
        document.getElementById("loginName").value = "";
        document.getElementById("loginPassword").value = "";
        if(jsonObject != 0) {
            jsonObject = JSON.stringify(jsonObject);
            console.log(jsonObject);
            setCookie("userData", jsonObject, 2);
            location.href = "/userPage.html";
        } else {
            document.getElementById("loginResult").innerHTML = "User/Password combination is incorrect";
        }
        //hideOrShow( "loginDiv", false);
        //hideOrShow( "menuDiv", true);
	}
	catch(err)
	{
		document.getElementById("loginResult").innerHTML = err.message;
	}
}

function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = "expires="+d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires;
}

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function showCreateAccount()
{
    hideOrShow("LogIn", false);
    hideOrShow("CreateAccount", true);
    document.getElementById("loginResult").innerHTML = " ";
}

function showLogIn()
{
    hideOrShow("LogIn", true);
    hideOrShow("CreateAccount", false);
    document.getElementById("loginResult").innerHTML = " ";
}

function placeholderLogin()
{
	//document.getElementById("userName").innerHTML = firstName + " " + lastName;
	document.getElementById("loginName").value = "";
	document.getElementById("loginPassword").value = "";

	hideOrShow( "loginDiv", false);
	hideOrShow( "contactDiv", true);
}

function ShowPass()
{
    var x = document.getElementById("loginPassword");
    if (x.type == "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}

function hideOrShow( elementId, showState )
{
	var vis = "visible";
	var dis = "block";
	if( !showState )
	{
		vis = "hidden";
		dis = "none";
	}

	document.getElementById( elementId ).style.visibility = vis;
	document.getElementById( elementId ).style.display = dis;
}

function sha1(msg)
//it have a 20 character salt added to the hash before sending this to the server
{
    //function used for later use
    function rotl(n,s)
    {
        return n<<s|n>>>32-s;
    };

    //function used for later use
    function tohex(i)
    {
        for(var h="", s=28;;s-=4)
        { h+=(i>>>s&0xf).toString(16);
            if(!s)
                return h;
        }
    };

    //var H0=0x67452301, H1=0xEFCDAB89, H2=0x98B1DCFE, H3=0xA0325476, H4=0xC3D2E1F0, M=0x0ffffffff; //salt
    var H0="", H1="", H2="", H3="", H4="", M="";
    var i, t, W=new Array(80), ml=msg.length, wa=new Array();
    msg += String.fromCharCode(0x80);

    while(msg.length%4)
        msg+=String.fromCharCode(0);

    for(i=0;i<msg.length;i+=4)
        wa.push(msg.charCodeAt(i)<<24|msg.charCodeAt(i+1)<<16|msg.charCodeAt(i+2)<<8|msg.charCodeAt(i+3));

    while(wa.length%16!=14)
        wa.push(0);
        wa.push(ml>>>29), wa.push((ml<<3)&M);

    for( var bo=0;bo<wa.length;bo+=16 )
    {
        for(i=0;i<16;i++)
            W[i]=wa[bo+i];

        for(i=16;i<=79;i++)
            W[i]=rotl(W[i-3]^W[i-8]^W[i-14]^W[i-16],1);

        var A=H0, B=H1, C=H2, D=H3, E=H4;

        for(i=0 ;i<=19;i++)
            t=(rotl(A,5)+(B&C|~B&D)+E+W[i]+0x5A827999)&M, E=D, D=C, C=rotl(B,30), B=A, A=t;

        for(i=20;i<=39;i++)
            t=(rotl(A,5)+(B^C^D)+E+W[i]+0x6ED9EBA1)&M, E=D, D=C, C=rotl(B,30), B=A, A=t;

        for(i=40;i<=59;i++)
            t=(rotl(A,5)+(B&C|B&D|C&D)+E+W[i]+0x8F1BBCDC)&M, E=D, D=C, C=rotl(B,30), B=A, A=t;

        for(i=60;i<=79;i++)
            t=(rotl(A,5)+(B^C^D)+E+W[i]+0xCA62C1D6)&M, E=D, D=C, C=rotl(B,30), B=A, A=t;

        H0=H0+A&M; H1=H1+B&M; H2=H2+C&M; H3=H3+D&M; H4=H4+E&M;
    }
    return tohex(H0)+tohex(H1)+tohex(H2)+tohex(H3)+tohex(H4);
}